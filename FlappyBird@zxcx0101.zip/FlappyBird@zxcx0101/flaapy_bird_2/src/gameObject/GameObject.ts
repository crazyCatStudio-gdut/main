class GameObject extends egret.DisplayObjectContainer{
	public constructor() {
		super();
	}
	public hasTrigger:boolean;//是否碰撞
	update(timeStamp:number){
		
	}
}